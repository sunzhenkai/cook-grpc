Services for Wii Gapic Cook v1 API
==================================
.. toctree::
    :maxdepth: 2

    cook_service
