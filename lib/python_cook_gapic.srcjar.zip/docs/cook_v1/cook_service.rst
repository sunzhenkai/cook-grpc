CookService
-----------------------------

.. automodule:: wii.gapic.cook_v1.services.cook_service
    :members:
    :inherited-members:
