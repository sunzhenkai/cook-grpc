Types for Wii Gapic Cook v1 API
===============================

.. automodule:: wii.gapic.cook_v1.types
    :members:
    :undoc-members:
    :show-inheritance:
